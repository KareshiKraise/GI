Chiba City Blues
===============================
Keenan Crane September 25, 2011

Files
--------------------------------------------
This archive contains a mesh of an abstract city.
It contains:

1. a polygonal mesh of the city
2. a triangulated mesh of the city
3. a mesh of a ground plane
4. baked indirect and environment-based lighting

The meshes include texture atlases for their respective textures.
All meshes are stored as Wavefront OBJ, all images are stored as PNG.



License
--------------------------------------------

As the sole author of this data, I hereby release it into the public domain.

